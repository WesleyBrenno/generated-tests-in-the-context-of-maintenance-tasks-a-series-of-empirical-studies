package collections.functors;

import java.io.Serializable;

import collections.Factory;
import collections.Transformer;

/**
 * Transformer implementation that calls a Factory and returns the result.
 * 
 */
public class FactoryTransformer implements Transformer, Serializable {

    /** Serial version UID */
    private static final long serialVersionUID = -6817674502475353160L;

    /** The factory to wrap */
    private final Factory iFactory;

    /**
     * Factory method that performs validation.
     * 
     * @param factory  the factory to call, not null
     * @return the <code>factory</code> transformer
     * @throws IllegalArgumentException if the factory is null
     */
    public static Transformer getInstance(Factory factory) {
        if (factory == null) {
            throw new IllegalArgumentException("Factory must not be null");
        }
        return new FactoryTransformer(factory);
    }

    /**
     * Constructor that performs no validation.
     * Use <code>getInstance</code> if you want that.
     * 
     * @param factory  the factory to call, not null
     */
    public FactoryTransformer(Factory factory) {
        super();
        iFactory = factory;
    }

    /**
     * Transforms the input by ignoring the input and returning the result of
     * calling the decorated factory.
     * 
     * @param input  the input object to transform
     * @return the transformed result
     */
    public Object transform(Object input) {
        return iFactory.create();
    }

    /**
     * Gets the factory.
     * 
     * @return the factory
     */
    public Factory getFactory() {
        return iFactory;
    }

}
